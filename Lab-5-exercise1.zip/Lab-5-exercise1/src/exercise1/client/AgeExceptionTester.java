package exercise1.client;

import java.util.Scanner;

import exercise1.AgeException;

public class AgeExceptionTester {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		try {
			System.out.println("Enter Age");
			int age=sc.nextInt();

			if(age<15)
			{
				throw new AgeException("Your age is not valid ");
			}
			System.out.println("Valid age");
		}
		catch(AgeException e)
		{
			e.printStackTrace();
		}
	}

}
