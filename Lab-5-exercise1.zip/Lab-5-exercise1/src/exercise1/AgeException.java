package exercise1;

public class AgeException extends Exception {
	private String msg;

	public AgeException()
	{
		
	}
	public AgeException(String msg) {
		
		this.msg = msg;
		//System.out.println(msg);
	}
	public String getMessage()
	{
		return this.msg;
	}

}
