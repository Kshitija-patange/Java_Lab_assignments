package com.cg.training.service;

public class ValidNameException extends Exception {
	String message;

	public ValidNameException(String message) {
		super();
		this.message = message;
	}
	public ValidNameException()
	{
		
	}
	public String getMessage()
	{
		return this.message;
	}

}
