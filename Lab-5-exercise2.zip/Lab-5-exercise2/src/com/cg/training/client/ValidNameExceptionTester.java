package com.cg.training.client;

import java.util.Scanner;

import com.cg.training.service.ValidNameException;

public class ValidNameExceptionTester {

	private static Scanner scanner=new Scanner(System.in);
	public static void main(String[] args) {
		try
		{
			//System.out.print("Enter fName");
			String fname="Kshitija";
			System.out.println();
			//System.out.print("Enter lName");
			String lname="";
			if(fname.isBlank() )
			{
				throw new ValidNameException("Enter First Name");
			}
			else if(lname.isBlank())
			{
				throw new ValidNameException("Enter Last Name");
			}
			System.out.println("Your name is correct");
		}catch(ValidNameException e)
		{
			e.printStackTrace();
		}

	}

}
