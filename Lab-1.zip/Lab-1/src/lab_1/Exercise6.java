package lab_1;
import java.util.*;
public class Exercise6 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter n");
		int n=sc.nextInt();
		Exercise6 obj=new Exercise6();
		System.out.println("Sum of the squares and square of the sum is "+obj.calculateDifference(n));

	}
	public int calculateDifference(int n)
	{
		int diff=0,s1=0,s2=0;
		for(int i=1;i<=n;i++)
		{
			s1=s1+(i*i);
			s2=s2+i;
		}
		diff=s1-(s2*s2);
		return diff;
	}

}
