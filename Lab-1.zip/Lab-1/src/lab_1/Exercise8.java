package lab_1;
import java.util.*;
public class Exercise8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		Exercise8 Obj =new Exercise8();
		System.out.println("Enter digit");
		int digit=sc.nextInt();
		if(Obj.checkNumber(digit))
			System.out.println(digit+" is power of 2");
		

	}
	public boolean checkNumber(int digit)
	{
		boolean flag=false;
		while(digit>0)
		{
			if(digit%2==0)
			{
				flag=true;
			}
			else
			{
				break;
			}
			digit=digit/2;
		}
		return flag;
	}

}
