package lab_1;

public class Exercise3_function {
	 void nrcf(int a,int b,int c,int n)
     {
                 for(int i=1;i<=n-2;i++)
                 {
                             c=a+b;
                             a=b;
                             b=c;
                 }
                 a=b=1;
                 System.out.println("Using non recursive function is : "+c);
                
     }
     void  rcf(int a,int b,int c,int n)
     {
                            
                 if(n-2>0)
                 {
                             c=a+b;
                             a=b;
                             b=c;
                             rcf(a,b,c,n-1);
                             return;
                 }
                
                 System.out.println("Using recursive function is : "+c);
     }

}
