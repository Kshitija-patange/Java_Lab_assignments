package lab_1;
import java.util.*;
public class Exercise7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		Exercise7 Obj =new Exercise7();
		System.out.println("Enter digit");
		int digit=sc.nextInt();
		if(Obj.checkNumber(digit))
			System.out.println(digit+" is increasing number");

	}
	public boolean checkNumber(int digit)
	{
		int n1=0,n2=0;
		boolean flag=true;
		int ctDig=digit%10;
		int number=digit/10;
		while(number>0)
		{
			
			if(ctDig> number%10)
			{
				flag=true;
			}
			else
			{
				flag=false;
				break;
			}
			ctDig=number%10;
			number=number/10;
		}
		return flag;
	}

}
