package lab_1;

import java.util.Scanner;

public class Exercise3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Exercise3_function f=new Exercise3_function();
         int n,a=1,b=1,c=0;
         Scanner scr=new Scanner(System.in);
         System.out.println("Enter n value:  ");
         n=scr.nextInt();
         f.nrcf(a,b,c,n);
         f.rcf(a,b,c,n);
        

	}

}
