package lab_1;
import java.util.*;
public class Exercise_1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		Exercise_1 Obj =new Exercise_1();
		System.out.println("Enter digit");
		int digit=sc.nextInt();
		System.out.println("Result"+Obj.CubeSum(digit));

	}
	
	public int CubeSum(int digit)
	{
		int n=0,sum=0;
		while(digit > 0)
        {
            n =digit % 10;
            sum = sum + (n*n*n);
            digit = digit / 10;
        }
		return sum;
	}

}
