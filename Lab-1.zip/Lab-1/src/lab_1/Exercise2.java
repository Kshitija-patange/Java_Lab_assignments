package lab_1;
import java.util.*;
public class Exercise2 {

	public static void main(String[] args) {
		String signal=new String();
		Scanner sc=new Scanner(System.in);
		
		do
		{
			signal=sc.next();
			switch(signal)
			{
			case "red":System.out.println("stop"); break;
			case "green":System.out.println("go"); break;
			case "yellow":System.out.println("ready"); break;
			default:System.out.println("invalid choice"); 
			
			}
		}
		while(true);

	}

}
