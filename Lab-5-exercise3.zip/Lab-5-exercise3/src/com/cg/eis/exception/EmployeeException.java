package com.cg.eis.exception;

public class EmployeeException extends Exception {
	String message;

	public EmployeeException(String message) {
		super();
		this.message = message;
	}
	public EmployeeException()
	{
		
	}
	public String getMessage()
	{
		return this.message;
	}

}
