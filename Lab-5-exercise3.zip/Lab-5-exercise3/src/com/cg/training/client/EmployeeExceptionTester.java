package com.cg.training.client;

import java.util.Scanner;

import com.cg.eis.exception.EmployeeException;

public class EmployeeExceptionTester {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Salary");
		int salary=sc.nextInt();
		getSalaryValid(salary);
	}

	private static void getSalaryValid(int salary) {
		// TODO Auto-generated method stub
		try
		{
			
			if(salary<3000)
			{
				throw new EmployeeException("low salary");
			}
			System.out.println(" Salary above limit");
		}catch(EmployeeException e)
		{
			e.printStackTrace();
		}

		
	}

}
