package com.cg.exercise3.client;

import com.cg.exercise3.service.Book;
import com.cg.exercise3.service.Video;

public class ItemTester {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Book bk=new Book(1,"Kahani",10,"Chetan Bhagat");
		bk.print();
		bk.checkIn();
		bk.print();
		System.out.println("---------------------------------");
		Video video = new Video(12, "SilentSongs", 30, 20, "R D Burman", "Peace", 1971);
		video.print();
		video.checkIn();
		video.print();

	}

}
