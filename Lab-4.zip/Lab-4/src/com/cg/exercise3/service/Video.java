package com.cg.exercise3.service;

public class Video extends MedialItem {
	private String director,genre;
	private int year;
	
	public Video(int idNum, String title, int copies, int runtime, String director, String genre, int year) {
		super(idNum, title, copies, runtime);
		this.director = director;
		this.genre = genre;
		this.year = year;
	}

	public String getDirector() {
		return director;
	}

	public void setDirector(String director) {
		this.director = director;
	}

	public String getGenre() {
		return genre;
	}

	public void setGenre(String genre) {
		this.genre = genre;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	@Override
	public void print() {
		// TODO Auto-generated method stub
		super.print();
		System.out.println("Director -> "+this.getDirector());
		System.out.println("Genre -> "+this.getGenre());
		System.out.println("Year of publish -> "+this.getYear());
	}
	

}
