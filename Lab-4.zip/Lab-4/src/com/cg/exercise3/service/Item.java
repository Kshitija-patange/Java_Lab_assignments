package com.cg.exercise3.service;



public class Item {
	private int idNum;
	private String title;
	private int copies;
	public Item(int idNum, String title, int copies) {
		super();
		this.idNum = idNum;
		this.title = title;
		this.copies = copies;
	}
	public int getIdNum() {
		return idNum;
	}
	public void setIdNum(int idNum) {
		this.idNum = idNum;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public int getCopies() {
		return copies;
	}
	public void setCopies(int copies) {
		this.copies = copies;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + copies;
		result = prime * result + idNum;
		result = prime * result + ((title == null) ? 0 : title.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if(obj == null)
		return false;
		
		Item otherItem = (Item) obj;
		return idNum == otherItem.idNum && 
			   title == otherItem.title && 
			   copies == otherItem.copies;
	}
	@Override
	public String toString() {
		return "Item [idNum=" + idNum + ", title=" + title + ", copies=" + copies + "]";
	}
	public void addItem(int idNum,String title,int copies)
	{
		this.setCopies(copies);
		this.setIdNum(idNum);
		this.setTitle(title);
	}
	public void print()
	{
		System.out.println("Id -> "+this.getIdNum());
		System.out.println("Title -> "+this.getTitle());
		System.out.println("Copies -> "+this.getCopies());
	}
	public void checkIn()
	{
		this.setCopies(this.getCopies()+1);
	}
	public void checkOut()
	{
		this.setCopies(this.getCopies()-1);
	}

}
