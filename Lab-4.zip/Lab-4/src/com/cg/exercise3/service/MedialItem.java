package com.cg.exercise3.service;

public class MedialItem extends Item {
	
	private int runtime;
	public MedialItem(int idNum, String title, int copies ,int runtime) {
		super(idNum, title, copies);
		// TODO Auto-generated constructor stub
		this.runtime=runtime;
	}
	@Override
	public void print() {
		// TODO Auto-generated method stub
		super.print();
		System.out.println("runtime -> "+this.getRuntime());
	}
	public int getRuntime() {
		return runtime;
	}
	public void setRuntime(int runtime) {
		this.runtime = runtime;
	}


}
