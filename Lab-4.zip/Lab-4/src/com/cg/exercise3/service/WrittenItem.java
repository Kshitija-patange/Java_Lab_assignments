package com.cg.exercise3.service;

public class WrittenItem extends Item {
	private String author;

	public WrittenItem(int idNum, String title, int copies ,String author) {
		super(idNum, title, copies);
		// TODO Auto-generated constructor stub
		this.author=author;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	@Override
	public void print() {
		// TODO Auto-generated method stub
		super.print();
		System.out.println("Author -> "+this.getAuthor());
	}
	
	

}
