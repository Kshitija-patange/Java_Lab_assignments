package com.cg.exercise3.service;

public class Book extends WrittenItem {

	public Book(int idNum, String title, int copies, String author) {
		super(idNum, title, copies, author);
		// TODO Auto-generated constructor stub
	}

}
