package com.cg.exercise3.service;

public class JournalPaper extends WrittenItem {

	@Override
	public void print() {
		// TODO Auto-generated method stub
		super.print();
		System.out.println("Year -> "+this.getYear());
	}
	private int year;
	public JournalPaper(int idNum, String title, int copies, String author ,int year) {
		super(idNum, title, copies, author);
		// TODO Auto-generated constructor stub
		this.year=year;
		
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}

}
