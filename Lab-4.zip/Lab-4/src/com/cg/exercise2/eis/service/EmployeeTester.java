package com.cg.exercise2.eis.service;

import com.cg.exercise2.eis.bean.Employee;
import com.cg.exercise2.eis.pl.EmployeeService;
import com.cg.exercise2.eis.pl.EmployeeServiceImpl;

public class EmployeeTester {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee e1=new Employee();
		EmployeeService employeeService=new EmployeeServiceImpl();
		employeeService.getEmployeeDetails(e1);
		 employeeService.getInsuranceScheme(e1);
		employeeService.showEmployeeDetails(e1);

	}

}
