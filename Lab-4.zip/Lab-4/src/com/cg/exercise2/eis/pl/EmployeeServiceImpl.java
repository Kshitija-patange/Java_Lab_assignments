package com.cg.exercise2.eis.pl;

import java.util.Scanner;

import com.cg.exercise2.eis.bean.Employee;

public class EmployeeServiceImpl implements EmployeeService{
public static Scanner sc=new Scanner(System.in);
	@Override
	public void getEmployeeDetails(Employee employee) {
		// TODO Auto-generated method stub
		System.out.println("Enter emp id");
		employee.setId(sc.nextInt());
		sc.nextLine();
		System.out.println("Enter emp name");
		employee.setName(sc.nextLine());
		//sc.nextLine();
		System.out.println("Enter emp salary");
		employee.setSalary(sc.nextDouble());
		sc.nextLine();
		System.out.println("Enter emp designation");
		employee.setDesignation(sc.nextLine());	
	}

	@Override
	public void getInsuranceScheme(Employee employee) {
		// TODO Auto-generated method stub
		if(employee.getSalary()<30000.00 && employee.getDesignation()=="Analyst")
		{
			employee.setInsuranceScheme("Analyst insurance");
		}
		else if(employee.getSalary()>30000.00 && employee.getSalary()<50000.00 && employee.getDesignation()=="Software engineer")
		{
			employee.setInsuranceScheme("software engineer insurance");
		}
		else
		{
			employee.setInsuranceScheme("Manager Insurance");
		}
		
	}

	@Override
	public void showEmployeeDetails(Employee employee) {
		// TODO Auto-generated method stub
	System.out.println("Employee details ---> ");
	System.out.println(employee.getId());
	System.out.println(employee.getName());
	System.out.println(employee.getDesignation());
	System.out.println(employee.getSalary());
	System.out.println(employee.getInsuranceScheme());
	

		
	}

}
