package com.cg.exercise2.eis.pl;

import com.cg.exercise2.eis.bean.Employee;

public interface EmployeeService {
	public void getEmployeeDetails(Employee employee);
	public void getInsuranceScheme(Employee employee);
	public void showEmployeeDetails(Employee employee);

}
