package com.cg.exercise1.tester;

import com.cg.exercise1.Account;

public class AccountTester {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Account A = new Account("Smith",30,45756987,2000);
		System.out.println(A);
		Account B = new Account("Kathy",35,45896988,3000);
		System.out.println(B);
		A.deposit(2000);
		System.out.println(A);
		B.withdraw(2000);
		System.out.println(B);

	}

}
