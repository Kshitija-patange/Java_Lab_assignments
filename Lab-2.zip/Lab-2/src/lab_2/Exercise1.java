package lab_2;

import java.util.Arrays;
import java.util.Scanner;

public class Exercise1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter size of an array");
		int size=sc.nextInt();
		int [] digits=new int[size];
		for(int i=0;i<size;i++)
		{
			System.out.println("Enter element");
			digits[i]=sc.nextInt();
		}
		System.out.println("Second Smallest element is --> "+getSecondSmallest(digits));

	}

	public static int getSecondSmallest(int [] digits) {
		// TODO Auto-generated method stub
		Arrays.sort(digits);
		return digits[1];
	}

}
