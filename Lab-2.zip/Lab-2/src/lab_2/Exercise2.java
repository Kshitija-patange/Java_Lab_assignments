package lab_2;

import java.util.Arrays;
import java.util.Scanner;

public class Exercise2 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter size");
		int size=Integer.parseInt(sc.nextLine());
		String [] Names=new String[size];
		for(int i=0;i<size;i++)
		{
			System.out.println("Enter name");
			Names[i]=sc.nextLine();
		}
		Names=sortStrings(Names).split(",");
		System.out.println("Final String -->"
				+ "");
		for(String s:Names)
		{
			System.out.println(s);
		}
		



	}

	private static String sortStrings(String [] Name) {
		Arrays.sort(Name);
		for(String s:Name)
		{
			System.out.println(s);
		}
		String left=new String();
		String right=new String();
		String Final=new String();
		if(Name.length%2==0)
		{
		for(int i=0;i<((Name.length)/2);i++)
		{
			left=left.concat(Name[i].toUpperCase());
			left=left.concat(",");
		}
		}
		else
		{
			for(int i=0;i<((Name.length)/2)+1;i++)
			{
				left=left.concat(Name[i].toUpperCase());
				left=left.concat(",");
			}
		}
		
		
		if(Name.length%2==0)
		{
		for(int i=((Name.length)/2) ;i<Name.length;i++)
		{
			right=right.concat(Name[i].toLowerCase());
			right=right.concat(",");
		}
		}
		else
		{
			for(int i=((Name.length)/2)+1 ;i<Name.length;i++)
			{
				right=right.concat(Name[i].toLowerCase());
				right=right.concat(",");
			}
		}
		Final=left.concat(right);
		return Final;
	}

}
