package lab_2;

import java.util.Arrays;
import java.util.Scanner;

public class Exercise4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter size of an array");
		int size=sc.nextInt();
		int [] digits=new int[size];
		for(int i=0;i<size;i++)
		{
			System.out.println("Enter element");
			digits[i]=sc.nextInt();
		}
		digits=modifyArray (digits);
		System.out.println("Final Array");
		for(int i=0;i<digits.length;i++)
			System.out.println(digits[i]);

	}

	private static int[] modifyArray(int[] digits) {
		// TODO Auto-generated method stub
		int size=digits.length;
		int [] sample=new int[size];
		int i=0,j=1;
		Arrays.sort(digits);
		
		for(i=0;i<size-1;i++)
		{
			if(digits[i]!=digits[i+1])
			{
				sample[j]=digits[i];
				j++;
			}
		}
		sample[j++]=digits[size-1];
		int nonzeros=0;
		for(i=0;i<sample.length;i++)
		{
			if(sample[i]!=0)
			{
				nonzeros++;
			}
		}
		int [] sample1=new int[nonzeros];
		for(i=0,j=0;i<sample.length;i++)
		{
			if(sample[i]!=0)
			{
				sample1[j]=sample[i];
				j++;
			}
		}
		int temp=0;
		for ( i = 0; i < sample1.length; i++) {     
            for ( j = i+1; j < sample1.length; j++) {     
               if(sample1[i] < sample1[j]) {    
                   temp = sample1[i];    
                   sample1[i] = sample1[j];    
                   sample1[j] = temp;    
               }     
            }
		
	
		
	}
		return sample1;
}
}
