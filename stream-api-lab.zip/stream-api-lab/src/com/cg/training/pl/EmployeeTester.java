package com.cg.training.pl;

import com.cg.training.service.EmployeeService;

public class EmployeeTester {
	private static EmployeeService service= new EmployeeService();
	
	public static void main(String[] args) {
		double totalSal= service.sumOfSalaries();
		System.out.println("Total salary= "+ totalSal);

		service.seniorMostEmployee();
		service.sortByAttribute();
		
		service.employeeWithoutManager();
		service.employeeWithoutDepartment();
		service.employeeServiceDuration();
		//service.deptWithCountOfEmployee();
		service.deptWithOutEmployee();
		service.employeeWithHireDate();
	}

}
