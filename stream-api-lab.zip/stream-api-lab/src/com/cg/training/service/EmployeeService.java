package com.cg.training.service;

import java.time.LocalDate;
import java.time.Period;
import java.time.temporal.ChronoUnit;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import com.cg.training.bean.Employee;
import com.cg.training.dao.EmployeeRepository;

public class EmployeeService {

	// 1.Find out the sum of salary of all employees. 
	public Double sumOfSalaries() {
		List<Employee> employeeList= EmployeeRepository.getEmployees();

		Optional<Double> optional= employeeList.stream()
				.map((e)->e.getSalary())
				.reduce((a,b)->a+b);

		if(optional.isPresent()) {
			return optional.get();
		}else {
			return 0.0;
		}
	}
	//other methods
	//2.Find out the senior most employee of an organization. 
	public void seniorMostEmployee()
	{
		List<Employee> employeeList= EmployeeRepository.getEmployees();
		Employee maxByDate = employeeList
				.stream()
				.min(Comparator.comparing(Employee::getHireDate)) // getting employee with min hiredate who is senior
				.get();
		System.out.println("The senior most employee is "+maxByDate.getFirstName()+" "+maxByDate.getLastName());

	}
	//3.Sort employees by their Firstname, employeeID , Department Id
	public void sortByAttribute()
	{

		List<Employee> employeeList= EmployeeRepository.getEmployees();
		System.out.println("Sort By first name--------------------------------------------------------------");
		List<Employee> sortByFirstName =employeeList
				.stream()
				.sorted(Comparator.comparing(Employee::getFirstName))
				.collect(Collectors.toList());
		sortByFirstName.forEach(System.out::println);
		System.out.println("Sort By Employee id--------------------------------------------------------------");
		List<Employee> sortByEmployeeID =employeeList
				.stream()
				.sorted(Comparator.comparing(Employee::getEmployeeId))
				.collect(Collectors.toList());
		sortByEmployeeID.forEach(System.out::println);
	}
	//4.Find employees who didn�t report to anyone
	public void employeeWithoutManager()
	{
		List<Employee> employeeList= EmployeeRepository.getEmployees();
		List<Employee> noManagerEmployeeList= employeeList.stream()
				.filter((e) -> e.getManagerId()==null)
				.collect(Collectors.toList());
		System.out.println("Employee with no manager--------------------------------------------------");
		noManagerEmployeeList.stream().forEach(System.out::println); // print all employee details 
	}
	//5.Find out employees without department.
	public void employeeWithoutDepartment()
	{
		List<Employee> employeeList= EmployeeRepository.getEmployees();
		List<Employee> noDepartmentEmployeeList= employeeList.stream()
				.filter((e) -> e.getDepartment()==null)
				.collect(Collectors.toList());
		System.out.println("Employee with no Department--------------------------------------------------");
		//noDepartmentEmployeeList.stream().forEach(System.out::println);
		noDepartmentEmployeeList.stream()
		.map(Employee::getFirstName)
		.forEach(System.out::println);//print only employee name in that arraylist
	}
	//6.List employee name and duration of their service in months and days. 
	public void employeeServiceDuration()
	{
		System.out.println("Employee with duration--------------------------------------------------");
		List<Employee> employeeList= EmployeeRepository.getEmployees();
		employeeList.stream()
		.forEach(e -> {
			Period period =e.getHireDate().until(LocalDate.now());
			System.out.println("Employee Id :"+e.getFirstName()+" "+e.getLastName()+
					" == Month:-"+ChronoUnit.MONTHS.between(e.getHireDate(), LocalDate.now())
					+" == Days:-"+period.getDays());
		});
	}
	//7.List out department names and count of employees in each department. 
	//Please run after commenting entries f employee with dept null
	public void deptWithCountOfEmployee()
	{
		System.out.println("Department with employee count --------------------------------------------------");
		List<Employee> employeeList= EmployeeRepository.getEmployees();
		Map<String, Long> employeeCountByDepartment =employeeList.stream()
				.collect(Collectors.groupingBy (dept -> dept.getDepartment().getDepartmentName (), Collectors.counting()));
		employeeCountByDepartment.entrySet().stream().forEach(e-> System.out.println(e));
	}
	//8.Find out department without employees.
	public void deptWithOutEmployee()
	{
		System.out.println("Dept with out Employee--------------------------------------------------");
		List<Employee> employeeList= EmployeeRepository.getEmployees();
		List<Employee> e=employeeList.stream().filter((employee)->employee.getDepartment().equals(null)).collect(Collectors.toList());
		System.out.println(e.size());
	}
	//9.List employee name, hire date and day of week on which employee has started. 
	public void employeeWithHireDate()
	{
		System.out.println("Employee with--------------------------------------------------");
		List<Employee> employeeList= EmployeeRepository.getEmployees();
		for (Employee employee :employeeList ) {
			System.out.print(employee.getFirstName());
			System.out.print(employee.getLastName());
			System.out.print(employee.getHireDate());
			System.out.print(employee.getHireDate().getDayOfWeek());
			System.out.println();
		}
	}

}
